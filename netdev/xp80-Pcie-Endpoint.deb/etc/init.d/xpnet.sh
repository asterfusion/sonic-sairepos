#!/bin/bash

start() {
    start_time=10
    /sbin/modprobe xp80-Pcie-Endpoint
    while [ ! -c /dev/xppcidev0 ] && [ "$start_time" -gt 0 ];
    do
        sleep 1;
        ((--start_time))
    done;
}

stop() {
    stop_time=10
    /sbin/modprobe -r -q xp80-Pcie-Endpoint
    while [ -c /dev/xppcidev0 ] && [ "$stop_time" -gt 0 ];
    do
        sleep 1;
        ((--stop_time))
    done;
}

case "$1" in 
    start)
       start
       ;;
    stop)
       stop
       ;;
    restart)
       stop
       start
       ;;
    status)
       ;;
    *)
       echo "Usage: $0 {start|stop|status|restart}"
esac
